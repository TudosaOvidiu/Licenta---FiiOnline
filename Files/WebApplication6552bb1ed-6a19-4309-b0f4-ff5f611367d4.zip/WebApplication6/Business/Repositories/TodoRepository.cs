﻿using System;
using System.Collections.Generic;
using System.Linq;
using Data.Context;
using Data.Entities;

namespace Business.Repositories
{
    public class TodoRepository : ITodoRepository
    {
        private readonly IDatabaseService _databaseService;

        public TodoRepository(IDatabaseService databaseService)
        {
            _databaseService = databaseService;
        }

        public IReadOnlyList<Todo> GetAll()
        {
            return _databaseService.Todos.ToList();
        }

        public Todo GetById(Guid id)
        {
            return _databaseService.Todos.FirstOrDefault(t => t.Id == id);
        }

        public void Add(Todo todo)
        {
            _databaseService.Todos.Add(todo);
            _databaseService.SaveChanges();
        }

        public void Edit(Todo todo)
        {
            _databaseService.Todos.Update(todo);
            _databaseService.SaveChanges();
        }

        public void Delete(Guid id)
        {
            var todo = GetById(id);
            _databaseService.Todos.Remove(todo);
            _databaseService.SaveChanges();
        }
    }
}
