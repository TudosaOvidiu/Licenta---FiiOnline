﻿using System;
using System.Collections.Generic;
using Data.Entities;

namespace Business.Repositories
{
    public interface ITodoRepository
    {
        IReadOnlyList<Todo> GetAll();
        Todo GetById(Guid id);
        void Add(Todo todo);
        void Edit(Todo todo);
        void Delete(Guid id);
    }
}