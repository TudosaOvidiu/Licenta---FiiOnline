﻿using System;

namespace Data.Entities
{
    public class Todo
    {
        private Todo()
        {
            // EF Core
        }

        public Guid Id { get; private set; }

        public string Description { get; private set; }

        public bool IsComplete { get; private set; }

        public static Todo Create(string description, bool isComplete)
        {
            var instance = new Todo { Id = Guid.NewGuid() };
            instance.Update(description, isComplete);
            return instance;
        }

        public void Update(string description, bool isComplete)
        {
            this.Description = description;
            this.IsComplete = isComplete;
        }
    }
}
