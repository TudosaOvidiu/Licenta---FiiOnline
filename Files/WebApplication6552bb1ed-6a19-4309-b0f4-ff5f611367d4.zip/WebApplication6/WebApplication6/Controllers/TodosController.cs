﻿using System;
using System.Collections.Generic;
using Business.Repositories;
using Data.Entities;
using Microsoft.AspNetCore.Mvc;
using WebApplication6.Models;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    public class TodosController : Controller
    {
        private readonly ITodoRepository _repository;

        public TodosController(ITodoRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public IEnumerable<Todo> Get()
        {
            return _repository.GetAll();
        }

        [HttpGet("{id}")]
        public Todo Get(Guid id)
        {
            return _repository.GetById(id);
        }

        [HttpPost]
        public void Post([FromBody]CreateTodoModel todo)
        {
            var entity = Todo.Create(todo.Description, todo.IsComplete);
            _repository.Add(entity);
        }

        [HttpPut("{id}")]
        public void Put(Guid id, [FromBody]UpdateTodoModel todo)
        {
            var entity = _repository.GetById(id);
            entity.Update(todo.Description, todo.IsComplete);
            // magic
            _repository.Edit(entity);
        }

        [HttpDelete("{id}")]
        public void Delete(Guid id)
        {
            _repository.Delete(id);
        }
    }
}
