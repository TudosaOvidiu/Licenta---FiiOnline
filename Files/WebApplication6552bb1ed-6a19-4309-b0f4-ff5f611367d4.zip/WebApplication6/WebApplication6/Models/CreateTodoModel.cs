﻿namespace WebApplication6.Models
{
    public class CreateTodoModel
    {
        public string Description { get; set; }

        public bool IsComplete { get; set; }
    }
}
