﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsureThat;

namespace Common
{
    public static class StringService
    {
        public static bool IsPalindome(this string input)
        {
            Ensure.That(input, "Not null").IsNotNullOrEmpty();
            //var i = 0;
            //var j = input.Length - 1;
            //while (i<j)
            //{
            //    if (input[i]!=input[j])
            //    {
            //        return false;
            //    }

            //    i++;
            //    j--;
            //}
            //return true;
            var reversedInput = input.Reverse();

            return reversedInput.Equals(input);
        }

        public static string Concatenate(params string[] values)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var value in values)
            {
                sb.Append(value);
            }

            return sb.ToString();
        }
    }
}
